#pragma once
#include <stdint.h>

/*
 * ============================================================
 *  os_app_cfg.h
 *  - Đây là lớp "cấu hình ứng dụng" nằm trên kernel.
 *  - File này định danh các task/alarm mà app đang dùng, đồng thời
 *    khai báo prototype để kernel có thể tham chiếu đúng symbol.
 *
 *  Tách riêng file này giúp:
 *  - kernel không phải hard-code tên hàm ứng dụng trong nhiều nơi
 *  - app có thể đổi mapping task/alarm mà không sửa port layer
 * ============================================================
 */

/* ------------------------------------------------------------
 * ID logic của task.
 * Thứ tự enum ở đây phải nhất quán với cấu hình trong OS_Init().
 * ------------------------------------------------------------ */
typedef enum {
    TASK_INIT = 0, /* Task khởi tạo phần cứng ban đầu */
    TASK_A,        /* Task điều khiển LED */
    TASK_B,        /* Task gửi UART */
    TASK_IDLE,     /* Task rỗi của hệ thống */
    TASK_COUNT     /* = OS_MAX_TASKS */
} TaskId_e;

/* ------------------------------------------------------------
 * ID logic của alarm.
 * Mỗi alarm hiện kích hoạt trực tiếp một task.
 * ------------------------------------------------------------ */
typedef enum {
    ALARM_A = 0,
    ALARM_B,
    ALARM_COUNT /* = OS_MAX_ALARMS */
} AlarmId_e;

/* Prototype của các task do ứng dụng hiện thực. */
void Task_Init(void *arg);
void Task_A(void *arg);
void Task_B(void *arg);
void Task_Idle(void *arg);

/* ------------------------------------------------------------
 * Tham số alarm mẫu theo đơn vị ms.
 * Kernel sẽ đổi các giá trị này sang tick bằng hàm ms_to_ticks().
 * ------------------------------------------------------------ */
#define ALARM_A_DELAY_MS    200u
#define ALARM_A_CYCLE_MS   1000u
#define ALARM_B_DELAY_MS    500u
#define ALARM_B_CYCLE_MS   1500u
