#pragma once

/*
 * ============================================================
 *  os_config.h
 *  - Chứa các cấu hình build-time của mini-kernel.
 *  - Đây là nơi điều chỉnh các hằng số toàn cục như:
 *      + tần số tick
 *      + số task / số alarm
 *      + thang priority
 *      + priority từng task
 *      + stack size từng task
 *
 *  Lưu ý:
 *  - Các giá trị ở file này được include trực tiếp vào kernel và port.
 *  - Vì vậy thay đổi ở đây sẽ ảnh hưởng ngay tới layout RAM, scheduler
 *    và chu kỳ alarm của toàn hệ thống.
 * ============================================================
 */

/* Tần số tick của OS.
 * 1000 Hz tương ứng 1 tick mỗi 1 ms. */
#define OS_TICK_HZ              1000u

/*
 * Semihosting chỉ nên bật khi debug trên probe/debugger hỗ trợ đầy đủ.
 * Với Renode + GDB batch, BKPT semihosting dễ làm phiên debug đứt giữa chừng.
 * Vì vậy mặc định để tắt; nếu cần có thể override thành 1 ở build khác.
 */
#ifndef OS_ENABLE_SEMIHOSTING
#define OS_ENABLE_SEMIHOSTING   0u
#endif

/*
 * WFI trong idle task hợp lý trên phần cứng thật, nhưng một số flow mô phỏng
 * và debug batch có thể cần override sang busy-idle để cô lập lỗi.
 * Sau khi sửa PendSV, mặc định hiện tại quay lại hành vi tiết kiệm năng lượng.
 */
#ifndef OS_IDLE_USE_WFI
#define OS_IDLE_USE_WFI         1u
#endif

/* Số lượng đối tượng tĩnh mà kernel quản lý. */
#define OS_MAX_TASKS            4u      /* Init, A, B, Idle */
#define OS_MAX_ALARMS           2u      /* AlarmA, AlarmB   */

/* ------------------------------------------------------------
 * Thang priority của hệ thống.
 * Giá trị càng lớn thì priority càng cao trong scheduler.
 * ------------------------------------------------------------ */
#define OS_PRIO_IDLE            0u
#define OS_PRIO_LOW             1u
#define OS_PRIO_MEDIUM          2u
#define OS_PRIO_HIGH            3u

/* Macro tiện dụng cho ready queue đa mức priority. */
#define OS_MAX_PRIORITY         OS_PRIO_HIGH
#define OS_PRIORITY_LEVELS      (OS_MAX_PRIORITY + 1u)

/* ------------------------------------------------------------
 * Priority tĩnh của từng task.
 * - INIT chạy ưu tiên cao nhất để setup hệ thống trước.
 * - TASK_A cao hơn TASK_B để dễ quan sát preemption.
 * - IDLE luôn là thấp nhất.
 * ------------------------------------------------------------ */
#define TASK_INIT_PRIORITY      OS_PRIO_HIGH
#define TASK_A_PRIORITY         OS_PRIO_MEDIUM
#define TASK_B_PRIORITY         OS_PRIO_LOW
#define TASK_IDLE_PRIORITY      OS_PRIO_IDLE

/* ------------------------------------------------------------
 * Giới hạn số lần activation tối đa.
 * Bản hiện tại đang để 1 để giữ semantics đơn giản:
 * - task chưa hỗ trợ queue nhiều activation song song.
 * - nếu cần mở rộng multi-activation, tăng giá trị ở đây trước.
 * ------------------------------------------------------------ */
#define TASK_INIT_MAX_ACTIVATIONS 1u
#define TASK_A_MAX_ACTIVATIONS    1u
#define TASK_B_MAX_ACTIVATIONS    1u
#define TASK_IDLE_MAX_ACTIVATIONS 1u

/* ------------------------------------------------------------
 * Kích thước stack tính theo số word 32-bit.
 * RAM tiêu thụ thực tế = STACK_WORDS_x * 4 byte.
 * ------------------------------------------------------------ */
#define STACK_WORDS_INIT        256u
#define STACK_WORDS_A           256u
#define STACK_WORDS_B           256u
#define STACK_WORDS_IDLE        128u
