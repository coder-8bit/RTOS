/*
 * =====================================================================
 *  os_kernel.c
 *  - Trái tim của mini-kernel.
 *
 *  File này hiện thực toàn bộ policy runtime:
 *  - ready queue theo priority
 *  - FIFO trong cùng priority
 *  - quản lý activation_count
 *  - alarm đơn giản dựa trên SysTick
 *  - scheduler/preemption
 *  - bootstrap task đầu tiên
 *
 *  Phân vai với các file khác:
 *  - os_kernel.c      : quyết định "ai chạy tiếp"
 *  - os_port.c        : cấu hình phần cứng để cơ chế đó khả thi
 *  - os_port_asm.s    : save/restore context thật sự
 *
 *  Một số ý quan trọng của thiết kế hiện tại:
 *  1. `g_current` là task đang chạy thật trên CPU.
 *  2. `g_next` là "vé chuyển cảnh" do scheduler cấp cho PendSV.
 *  3. Task mới activate lại sẽ chạy từ đầu entry function,
 *     không tiếp tục từ stack cũ.
 *  4. Scheduler không đổi ngữ cảnh trực tiếp trong ISR lồng nhau;
 *     nó đợi tới khi `g_interrupt_nesting == 0`.
 * =====================================================================
 */

#include "os_kernel.h"
#include "os_port.h"
#include "stm32f10x.h"

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#if (OS_MAX_TASKS < 2)
#error "OS_MAX_TASKS must be >= 2"
#endif

#if (OS_MAX_ALARMS < 1)
#error "OS_MAX_ALARMS must be >= 1"
#endif

/*
 * Ready queue cho một mức priority.
 * - buf[]  : lưu TaskID
 * - head   : vị trí pop
 * - tail   : vị trí push
 * - count  : số phần tử thực đang có
 *
 * Mỗi priority có một queue riêng để:
 * - giữ FIFO trong cùng priority
 * - vẫn dispatch deterministic khi quét từ priority cao xuống thấp
 */
typedef struct {
    uint8_t buf[OS_MAX_TASKS];
    uint8_t head;
    uint8_t tail;
    uint8_t count;
} OsReadyQueuePrio_t;

/* ------------------------------------------------------------
 * Biến toàn cục mà assembly cũng cần đọc/ghi.
 * ------------------------------------------------------------ */
volatile TCB_t *g_current = NULL;
volatile TCB_t *g_next = NULL;
volatile uint8_t g_interrupt_nesting = 0u;
volatile uint32_t g_tick_count = 0u;

/* ------------------------------------------------------------
 * Vùng dữ liệu runtime tĩnh của kernel.
 * - tcb[]         : bảng task control block
 * - stack_*[]     : vùng stack riêng của từng task
 * - ready_queues  : ready queue nhiều mức priority
 * - task_queued[] : cờ chống enqueue trùng
 * - alarm_tbl[]   : runtime state của alarm
 * ------------------------------------------------------------ */
static TCB_t tcb[OS_MAX_TASKS];

static uint32_t stack_init[STACK_WORDS_INIT];
static uint32_t stack_a[STACK_WORDS_A];
static uint32_t stack_b[STACK_WORDS_B];
static uint32_t stack_idle[STACK_WORDS_IDLE];

static OsReadyQueuePrio_t ready_queues[OS_PRIORITY_LEVELS];
static bool task_queued[OS_MAX_TASKS];
static OsAlarm_t alarm_tbl[OS_MAX_ALARMS];

/*
 * os_irq_save():
 * - đọc trạng thái PRIMASK hiện tại
 * - disable IRQ
 * - trả về giá trị cũ để caller có thể restore đúng trạng thái trước đó
 *
 * Cách làm này an toàn hơn việc luôn __enable_irq() ở cuối hàm, vì:
 * - nếu caller vốn đã đang ở critical section bên ngoài, ta không phá ngữ cảnh đó
 */
static inline uint32_t os_irq_save(void)
{
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    __DSB();
    __ISB();
    return primask;
}

/*
 * os_irq_restore():
 * - khôi phục đúng trạng thái PRIMASK đã lưu trước đó
 * - không "mở ngắt bừa" nếu trước đó ngắt vốn đang bị mask
 */
static inline void os_irq_restore(uint32_t primask)
{
    __DSB();
    __ISB();
    __set_PRIMASK(primask);
}

/* Bóp priority về miền hợp lệ để tránh truy cập ra ngoài mảng ready queue. */
static inline uint8_t os_clamp_priority(uint8_t prio)
{
    return (prio > OS_MAX_PRIORITY) ? (uint8_t)OS_MAX_PRIORITY : prio;
}

/* Tính địa chỉ "đỉnh stack" logic từ base + số word đã cấp. */
static inline uint32_t *os_task_stack_top(const TCB_t *task)
{
    return task->stack_base + task->stack_words;
}

/*
 * Reset toàn bộ ready queue và cờ task_queued.
 * Hàm này chỉ reset runtime state, không tự enqueue task nào.
 */
static inline void os_ready_queue_reset(void)
{
    for (uint8_t prio = 0u; prio < OS_PRIORITY_LEVELS; ++prio)
    {
        ready_queues[prio].head = 0u;
        ready_queues[prio].tail = 0u;
        ready_queues[prio].count = 0u;
    }

    for (uint8_t tid = 0u; tid < OS_MAX_TASKS; ++tid)
    {
        task_queued[tid] = false;
    }
}

/* Enqueue vào cuối queue của một priority -> giữ FIFO chuẩn trong cùng priority. */
static inline void os_ready_enqueue_tail(uint8_t prio, uint8_t tid)
{
    OsReadyQueuePrio_t *q = &ready_queues[prio];
    if (q->count >= OS_MAX_TASKS)
    {
        return;
    }

    q->buf[q->tail] = tid;
    q->tail = (uint8_t)((q->tail + 1u) % OS_MAX_TASKS);
    q->count++;
    task_queued[tid] = true;
}

/* Enqueue vào đầu queue -> dùng khi task đang chạy bị preempt. */
static inline void os_ready_enqueue_head(uint8_t prio, uint8_t tid)
{
    OsReadyQueuePrio_t *q = &ready_queues[prio];
    if (q->count >= OS_MAX_TASKS)
    {
        return;
    }

    q->head = (uint8_t)((q->head + OS_MAX_TASKS - 1u) % OS_MAX_TASKS);
    q->buf[q->head] = tid;
    q->count++;
    task_queued[tid] = true;
}

/*
 * Thêm task vào ready queue theo đường "bình thường".
 * Điều kiện:
 * - TaskID hợp lệ
 * - chưa nằm sẵn trong queue
 */
static inline void os_ready_add(uint8_t tid, uint8_t prio)
{
    if ((tid >= OS_MAX_TASKS) || task_queued[tid])
    {
        return;
    }

    tcb[tid].state = OS_READY;
    os_ready_enqueue_tail(os_clamp_priority(prio), tid);
}

/* Biến thể add-front để giữ tính công bằng khi task đang chạy bị đẩy ra vì preemption. */
static inline void os_ready_add_front(uint8_t tid, uint8_t prio)
{
    if ((tid >= OS_MAX_TASKS) || task_queued[tid])
    {
        return;
    }

    tcb[tid].state = OS_READY;
    os_ready_enqueue_head(os_clamp_priority(prio), tid);
}

/* Chỉ nhìn task priority cao nhất đang READY, không lấy nó ra khỏi queue. */
static uint8_t os_ready_peek_highest(void)
{
    for (int prio = (int)OS_MAX_PRIORITY; prio >= 0; --prio)
    {
        const OsReadyQueuePrio_t *q = &ready_queues[prio];
        if (q->count > 0u)
        {
            return q->buf[q->head];
        }
    }

    return OS_INVALID_TASK_ID;
}

/* Pop task priority cao nhất, đồng thời clear cờ task_queued tương ứng. */
static uint8_t os_ready_pop_highest(void)
{
    for (int prio = (int)OS_MAX_PRIORITY; prio >= 0; --prio)
    {
        OsReadyQueuePrio_t *q = &ready_queues[prio];
        if (q->count > 0u)
        {
            uint8_t tid = q->buf[q->head];
            q->head = (uint8_t)((q->head + 1u) % OS_MAX_TASKS);
            q->count--;
            task_queued[tid] = false;
            return tid;
        }
    }

    return OS_INVALID_TASK_ID;
}

/*
 * Đổi mili-giây sang số tick của OS.
 * Công thức làm tròn lên để delay > 0 luôn tương ứng ít nhất 1 tick.
 */
static inline uint32_t ms_to_ticks(uint32_t ms)
{
    if (ms == 0u)
    {
        return 0u;
    }

    uint64_t ticks = ((uint64_t)ms * (uint64_t)OS_TICK_HZ + 999ull) / 1000ull;
    if (ticks == 0ull)
    {
        ticks = 1ull;
    }
    if (ticks > 0xFFFFFFFFull)
    {
        ticks = 0xFFFFFFFFull;
    }
    return (uint32_t)ticks;
}

/*
 * Gán toàn bộ metadata ban đầu cho một task.
 * Hàm này chỉ cấu hình TCB, chưa tự động enqueue task.
 */
static void os_task_setup(uint8_t tid,
                          uint32_t *stack_base,
                          uint32_t stack_words,
                          void (*entry)(void *),
                          void *arg,
                          uint8_t priority,
                          uint8_t max_activations,
                          OsTaskState_e initial_state)
{
    TCB_t *task = &tcb[tid];

    task->sp = NULL;
    task->stack_base = stack_base;
    task->stack_words = stack_words;
    task->entry = entry;
    task->arg = arg;
    task->id = tid;
    task->base_priority = os_clamp_priority(priority);
    task->current_priority = task->base_priority;
    task->max_activations = (max_activations == 0u) ? 1u : max_activations;
    task->activation_count = (initial_state == OS_DORMANT) ? 0u : 1u;
    task->context_needs_init = 1u;
    task->state = (uint8_t)initial_state;
}

/*
 * Reset runtime state của tất cả alarm về trạng thái "tắt".
 * Thông tin delay/cycle thực sẽ được SetRelAlarm() nạp sau.
 */
static void os_alarm_reset_all(void)
{
    for (uint8_t i = 0u; i < OS_MAX_ALARMS; ++i)
    {
        alarm_tbl[i].active = 0u;
        alarm_tbl[i].target_task = OS_INVALID_TASK_ID;
        alarm_tbl[i].remain_ms = 0u;
        alarm_tbl[i].cycle_ms = 0u;
    }
}

/* Được gọi ở đầu một ISR do kernel quản lý để tăng nesting level. */
static void os_isr_enter(void)
{
    g_interrupt_nesting++;
}

/*
 * Được gọi ở cuối ISR.
 * Chỉ khi đây là ISR ngoài cùng (`g_interrupt_nesting == 0`) thì scheduler
 * mới được quyền quyết định preemption/reschedule.
 */
static void os_isr_exit(void)
{
    if (g_interrupt_nesting > 0u)
    {
        g_interrupt_nesting--;
    }

    if (g_interrupt_nesting == 0u)
    {
        os_schedule();
    }
}

/*
 * Helper cho assembly SVC/PendSV.
 *
 * Ý nghĩa:
 * - Nếu task chưa có context hợp lệ, dựng lại stack frame từ entry/arg.
 * - Nếu task đã có stack hợp lệ thì trả lại sp hiện có.
 *
 * Đây là điểm móc giữa scheduler logic và cơ chế save/restore ở assembly.
 */
uint32_t *os_get_task_stack_ptr_for_switch(TCB_t *task)
{
    if (task == NULL)
    {
        return NULL;
    }

    if ((task->context_needs_init != 0u) || (task->sp == NULL))
    {
        task->sp = os_task_stack_init(task->entry, task->arg, os_task_stack_top(task));
        task->context_needs_init = 0u;
    }

    return task->sp;
}

/*
 * os_dispatch():
 * - không tự chọn task
 * - không đụng ready queue
 * - chỉ chuyển "quyết định đã có" sang CPU bằng cách trigger PendSV
 */
void os_dispatch(void)
{
    if (g_next == NULL)
    {
        return;
    }

    os_trigger_pendsv();
}

/*
 * os_schedule():
 * Scheduler chính của hệ thống.
 *
 * Hai tình huống lớn:
 * 1. current không còn RUNNING
 *    -> lấy ngay task READY tốt nhất để chạy thay
 *
 * 2. current đang RUNNING
 *    -> chỉ preempt nếu có task READY priority cao hơn
 *
 * Hàm này cố tình không restore context trực tiếp.
 * Nó chỉ set `g_next`, rồi để PendSV thực hiện context switch thật.
 */
void os_schedule(void)
{
    bool need_dispatch = false;
    uint32_t primask = os_irq_save();
    TCB_t *current = (TCB_t *)g_current;

    /*
     * Không schedule khi:
     * - còn đang ở trong ISR nesting
     * - hoặc đã có một context switch pending trong g_next
     */
    if ((g_interrupt_nesting > 0u) || (g_next != NULL))
    {
        os_irq_restore(primask);
        return;
    }

    if (current == NULL)
    {
        os_irq_restore(primask);
        return;
    }

    /*
     * Nhánh 1:
     * current không còn RUNNING, nghĩa là task hiện hành vừa terminate/block
     * hoặc bootstrap xong và CPU cần tìm task khác để chạy.
     */
    if (current->state != OS_RUNNING)
    {
        uint8_t next_id = os_ready_pop_highest();
        /*
         * Nếu không còn ready task ứng dụng, fallback sang IDLE để CPU luôn có
         * một ngữ cảnh hợp lệ để quay về.
         */
        if ((next_id == OS_INVALID_TASK_ID) && (current->id != TASK_IDLE))
        {
            next_id = TASK_IDLE;
        }
        if (next_id != OS_INVALID_TASK_ID)
        {
            TCB_t *next = &tcb[next_id];
            next->state = OS_RUNNING;
            g_next = next;
            need_dispatch = true;
        }
    }
    else
    {
        /*
         * Nhánh 2:
         * current vẫn đang chạy bình thường, nên chỉ đổi ngữ cảnh nếu thật sự
         * có task READY priority cao hơn.
         */
        uint8_t peek_id = os_ready_peek_highest();
        if (peek_id != OS_INVALID_TASK_ID)
        {
            TCB_t *peek = &tcb[peek_id];
            if (peek->current_priority > current->current_priority)
            {
                /*
                 * Task đang chạy bị preempt:
                 * - đổi state về READY
                 * - đẩy nó lại vào đầu queue priority hiện tại
                 */
                current->state = OS_READY;
                os_ready_add_front(current->id, current->current_priority);

                peek_id = os_ready_pop_highest();
                if (peek_id != OS_INVALID_TASK_ID)
                {
                    TCB_t *next = &tcb[peek_id];
                    next->state = OS_RUNNING;
                    g_next = next;
                    need_dispatch = true;
                }
            }
        }
    }

    os_irq_restore(primask);

    if (need_dispatch)
    {
        os_dispatch();
    }
}

/*
 * ActivateTask():
 * - API kích hoạt task từ alarm hoặc từ code ứng dụng.
 * - Với thiết kế hiện tại, task chỉ được đưa vào ready queue khi đang DORMANT.
 * - activation_count vẫn tăng trước để giữ semantics mở rộng cho tương lai.
 */
void ActivateTask(uint8_t tid)
{
    bool run_scheduler = false;

    if ((tid >= OS_MAX_TASKS) || (tid == TASK_IDLE))
    {
        return;
    }

    uint32_t primask = os_irq_save();
    TCB_t *task = &tcb[tid];

    /* Chặn vượt quá giới hạn activation mà cấu hình cho phép. */
    if (task->activation_count >= task->max_activations)
    {
        os_irq_restore(primask);
        return;
    }

    task->activation_count++;

    /*
     * Chỉ khi task đang DORMANT mới cần:
     * - reset priority runtime
     * - đánh dấu phải dựng lại context từ đầu
     * - đưa vào ready queue
     */
    if (task->state == OS_DORMANT)
    {
        task->current_priority = task->base_priority;
        task->context_needs_init = 1u;
        task->sp = NULL;
        task->state = OS_READY;
        os_ready_add(task->id, task->current_priority);
    }

    /* Nếu không ở trong ISR thì có thể gọi scheduler ngay sau khi mở khóa. */
    if (g_interrupt_nesting == 0u)
    {
        run_scheduler = true;
    }

    os_irq_restore(primask);

    if (run_scheduler)
    {
        os_schedule();
    }
}

/*
 * TerminateTask():
 * - kết thúc activation hiện tại của task đang chạy
 * - reset runtime state cần thiết
 * - nếu còn activation pending thì enqueue lại để chạy từ đầu
 * - cuối cùng gọi scheduler chọn task tiếp theo
 */
void TerminateTask(void)
{
    uint32_t primask = os_irq_save();
    TCB_t *current = (TCB_t *)g_current;

    if (current != NULL)
    {
        if (current->activation_count > 0u)
        {
            current->activation_count--;
        }

        /* Task kết thúc thì priority động phải quay về base priority ban đầu. */
        current->current_priority = current->base_priority;
        current->context_needs_init = 1u;
        current->sp = NULL;

        /*
         * Nếu activation_count vẫn còn > 0 sau khi trừ đi activation hiện tại,
         * task sẽ chạy lại từ đầu entry() ở lần dispatch tiếp theo.
         */
        if (current->activation_count > 0u)
        {
            current->state = OS_READY;
            os_ready_add(current->id, current->current_priority);
        }
        else
        {
            current->state = OS_DORMANT;
        }
    }

    os_irq_restore(primask);
    /* Chọn task kế tiếp sau khi current đã tự kết thúc. */
    os_schedule();

    /*
     * Không bao giờ quay lại phần thân task vừa terminate.
     * Nếu assembly chưa switch ngay lập tức, CPU sẽ dừng trong vòng NOP này.
     */
    for (;;)
    {
        __NOP();
    }
}

/* Cấu hình alarm tương đối kiểu đơn giản nhất: delay + cycle + target task. */
void SetRelAlarm(uint8_t aid, uint32_t delay_ms, uint32_t cycle_ms, uint8_t target_tid)
{
    if ((aid >= OS_MAX_ALARMS) || (target_tid >= OS_MAX_TASKS) || (target_tid == TASK_IDLE))
    {
        return;
    }

    uint32_t primask = os_irq_save();
    OsAlarm_t *alarm = &alarm_tbl[aid];

    /*
     * Lưu ý:
     * remain_ms và cycle_ms từ đây trở đi đang lưu theo tick,
     * không còn là milli-giây thô nữa.
     */
    alarm->active = 1u;
    alarm->target_task = target_tid;
    alarm->remain_ms = ms_to_ticks((delay_ms == 0u) ? 1u : delay_ms);
    alarm->cycle_ms = ms_to_ticks(cycle_ms);

    os_irq_restore(primask);
}

/*
 * os_on_tick():
 * Hàm service được gọi bởi SysTick interrupt mỗi 1 ms.
 *
 * Trình tự:
 * 1. vào ISR -> tăng nesting
 * 2. tăng bộ đếm tick toàn cục
 * 3. quét từng alarm
 * 4. alarm hết hạn -> ActivateTask()
 * 5. ra ISR -> nếu là ISR ngoài cùng thì scheduler chạy
 */
void os_on_tick(void)
{
    os_isr_enter();
    g_tick_count++;

    for (uint8_t i = 0u; i < OS_MAX_ALARMS; ++i)
    {
        OsAlarm_t *alarm = &alarm_tbl[i];
        /* Bỏ qua alarm không hoạt động. */
        if (alarm->active == 0u)
        {
            continue;
        }

        /* Đếm lùi về 0 theo từng tick. */
        if (alarm->remain_ms > 0u)
        {
            alarm->remain_ms--;
        }

        /*
         * Khi countdown chạm 0:
         * - kích task đích
         * - nếu là cyclic thì nạp lại chu kỳ
         * - nếu là one-shot thì tắt alarm
         */
        if (alarm->remain_ms == 0u)
        {
            ActivateTask(alarm->target_task);

            if (alarm->cycle_ms > 0u)
            {
                alarm->remain_ms = alarm->cycle_ms;
            }
            else
            {
                alarm->active = 0u;
            }
        }
    }

    os_isr_exit();
}

/* Alias giữ tương thích nếu nơi khác gọi tên cũ. */
void os_tick_handler(void)
{
    os_on_tick();
}

/*
 * OS_Init():
 * Hàm khởi tạo "lạnh" của kernel.
 * Đây là nơi duy nhất cấu hình toàn bộ task/alarm tĩnh của hệ thống hiện tại.
 */
void OS_Init(void)
{
    uint32_t primask = os_irq_save();

    /* Reset mọi global về trạng thái sạch trước khi dựng hệ thống. */
    g_current = NULL;
    g_next = NULL;
    g_interrupt_nesting = 0u;
    g_tick_count = 0u;

    /* Cấu hình phần cứng phụ thuộc kiến trúc trước khi scheduler chạy. */
    os_port_init();
    os_ready_queue_reset();
    os_alarm_reset_all();

    /* Cấu hình metadata cho từng task ứng dụng. */
    os_task_setup(TASK_INIT,
                  stack_init,
                  STACK_WORDS_INIT,
                  Task_Init,
                  NULL,
                  TASK_INIT_PRIORITY,
                  TASK_INIT_MAX_ACTIVATIONS,
                  OS_READY);

    os_task_setup(TASK_A,
                  stack_a,
                  STACK_WORDS_A,
                  Task_A,
                  NULL,
                  TASK_A_PRIORITY,
                  TASK_A_MAX_ACTIVATIONS,
                  OS_DORMANT);

    os_task_setup(TASK_B,
                  stack_b,
                  STACK_WORDS_B,
                  Task_B,
                  NULL,
                  TASK_B_PRIORITY,
                  TASK_B_MAX_ACTIVATIONS,
                  OS_DORMANT);

    os_task_setup(TASK_IDLE,
                  stack_idle,
                  STACK_WORDS_IDLE,
                  Task_Idle,
                  NULL,
                  TASK_IDLE_PRIORITY,
                  TASK_IDLE_MAX_ACTIVATIONS,
                  OS_READY);

    /*
     * Nạp các task autostart ban đầu.
     * Trong demo này:
     * - INIT phải chạy ngay
     * - IDLE luôn tồn tại như fallback cuối
     */
    os_ready_add(TASK_INIT, tcb[TASK_INIT].current_priority);
    os_ready_add(TASK_IDLE, tcb[TASK_IDLE].current_priority);

    /* Lấy task đầu tiên có priority cao nhất để bootstrap qua SVC. */
    uint8_t first_id = os_ready_pop_highest();
    if (first_id == OS_INVALID_TASK_ID)
    {
        first_id = TASK_IDLE;
    }

    g_current = &tcb[first_id];
    ((TCB_t *)g_current)->state = OS_RUNNING;

    /* Cài hai alarm mẫu để minh họa task định kỳ. */
    SetRelAlarm(ALARM_A, ALARM_A_DELAY_MS, ALARM_A_CYCLE_MS, TASK_A);
    SetRelAlarm(ALARM_B, ALARM_B_DELAY_MS, ALARM_B_CYCLE_MS, TASK_B);

    os_irq_restore(primask);
}

/*
 * OS_Start():
 * Hàm này chỉ phát lệnh SVC để nhảy vào SVC_Handler.
 * Từ thời điểm đó, CPU sẽ bắt đầu dùng PSP và chạy task đầu tiên.
 */
void OS_Start(void)
{
    __ASM volatile("svc 0");
}
