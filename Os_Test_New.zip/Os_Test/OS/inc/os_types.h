#pragma once
#include <stdint.h>

/*
 * ============================================================
 *  os_types.h
 *  - Tập hợp các kiểu dữ liệu runtime nhỏ gọn mà kernel dùng nhiều nơi.
 *  - Tách file này giúp giảm phụ thuộc vòng giữa kernel header và app config.
 * ============================================================
 */

/* ------------------------------------------------------------
 * Trạng thái task ở runtime.
 * - DORMANT: task chưa nằm trong ready queue, chưa được chọn để chạy.
 * - READY:   task đã sẵn sàng, đang chờ scheduler dispatch.
 * - RUNNING: task đang là ngữ cảnh hiện tại trên CPU.
 * - WAITING: giữ chỗ cho hướng mở rộng event/blocking về sau.
 * ------------------------------------------------------------ */
typedef enum {
    OS_DORMANT = 0,
    OS_READY   = 1,
    OS_RUNNING = 2,
    OS_WAITING = 3
} OsTaskState_e;

/* ------------------------------------------------------------
 * Runtime state của một alarm tối giản.
 * - active:      1 nếu alarm đang chạy.
 * - remain_ms:   số tick còn lại trước lần kích tiếp theo.
 * - cycle_ms:    chu kỳ lặp; 0 nghĩa là one-shot.
 * - target_task: task sẽ được ActivateTask() khi alarm hết hạn.
 *
 * Tên field giữ hậu tố "_ms" để dễ đọc từ góc nhìn ứng dụng,
 * nhưng sau khi SetRelAlarm() chúng đang lưu theo đơn vị tick.
 * ------------------------------------------------------------ */
typedef struct {
    uint8_t   active;
    uint32_t  remain_ms;
    uint32_t  cycle_ms;
    uint8_t   target_task; /* TaskId_e */
} OsAlarm_t;
