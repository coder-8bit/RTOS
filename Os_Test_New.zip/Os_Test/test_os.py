#!/usr/bin/env python3
"""
test_os.py
-----------
Smoke test cho Os_Test bằng Renode theo thời gian ảo, không phụ thuộc GDB.

Kịch bản:
1. Kiểm tra ELF và file Renode script gốc tồn tại.
2. Sinh một file .resc tạm với đường dẫn ELF/log tuyệt đối.
3. Dùng `emulation RunFor` để chạy firmware đủ lâu trong virtual time.
4. Đọc log UART/GPIO của Renode và kiểm tra các mốc hành vi quan trọng:
   - boot hoàn tất
   - Task_A đã chạy ít nhất một lần
   - Task_B đã chạy ít nhất một lần
"""

from pathlib import Path
import os
import subprocess
import sys


PROJECT_ROOT = Path(__file__).resolve().parent
BUILD_DIR = Path(os.environ.get("OS_TEST_BUILD_DIR", PROJECT_ROOT / "build" / "os_test"))
ELF_PATH = Path(os.environ.get("OS_TEST_ELF", BUILD_DIR / "os_test.elf"))
RENODE_SCRIPT = Path(os.environ.get("OS_TEST_RENODE_SCRIPT", PROJECT_ROOT / "renode.resc"))
RENODE_LOG = Path(os.environ.get("OS_TEST_RENODE_LOG", BUILD_DIR / "renode_test.log"))
TEMP_RENODE_SCRIPT = BUILD_DIR / "renode_test.resc"
RUN_FOR = os.environ.get("OS_TEST_RUNFOR", "1.2")

RENODE_BIN = os.environ.get("RENODE_BIN")
if not RENODE_BIN:
    default_renode = Path("/Applications/Renode.app/Contents/MacOS/renode")
    RENODE_BIN = str(default_renode if default_renode.exists() else "renode")


def rel_path(path: Path) -> str:
    try:
        return path.resolve().relative_to(PROJECT_ROOT.resolve()).as_posix()
    except ValueError:
        return path.resolve().as_posix()


def build_temp_resc() -> None:
    resc_text = RENODE_SCRIPT.read_text(encoding="utf-8")
    filtered_lines = []

    for line in resc_text.splitlines():
        stripped = line.strip()
        if stripped.startswith("$elf_path ?="):
            filtered_lines.append(f"$elf_path ?= @{ELF_PATH.resolve().as_posix()}")
        elif stripped.startswith("$gpio_log_path ?="):
            filtered_lines.append(f"$gpio_log_path ?= @{RENODE_LOG.resolve().as_posix()}")
        elif stripped.startswith("$gdb_port ?="):
            continue
        elif stripped.startswith("machine StartGdbServer"):
            continue
        elif stripped == 'echo "Renode ready for GDB connection on configured port. Use \'start\' to begin simulation."':
            continue
        else:
            filtered_lines.append(line)

    filtered_lines.append(f'emulation RunFor "{RUN_FOR}"')
    filtered_lines.append("quit")
    TEMP_RENODE_SCRIPT.write_text("\n".join(filtered_lines) + "\n", encoding="utf-8")


def run_test() -> int:
    BUILD_DIR.mkdir(parents=True, exist_ok=True)

    if not ELF_PATH.exists():
        print(f"FAILED: ELF not found at {ELF_PATH}")
        return 1

    if not RENODE_SCRIPT.exists():
        print(f"FAILED: Renode script not found at {RENODE_SCRIPT}")
        return 1

    build_temp_resc()

    renode_cmd = [
        RENODE_BIN,
        "--console",
        "--disable-gui",
        "-e",
        f"i @{rel_path(TEMP_RENODE_SCRIPT)}",
    ]

    print("Starting Renode...")
    try:
        proc = subprocess.run(
            renode_cmd,
            cwd=PROJECT_ROOT,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=30,
            check=False,
        )
    except subprocess.TimeoutExpired:
        print("FAILED: Renode run timed out.")
        print(f"Renode log: {RENODE_LOG}")
        return 1
    except FileNotFoundError as exc:
        print(f"FAILED: Tool not found: {exc}")
        return 1

    if proc.stdout:
        print(proc.stdout)

    if not RENODE_LOG.exists():
        print(f"FAILED: Renode log not found: {RENODE_LOG}")
        return 1

    log_text = RENODE_LOG.read_text(encoding="utf-8", errors="replace")
    hit_boot = "[BOOT] Peripherals initialized." in log_text
    hit_a = "[LED] Task_A" in log_text
    hit_b = "[UART] Hello from Task_B" in log_text

    print("Test Results:")
    print(f"- Hit boot: {'YES' if hit_boot else 'NO'}")
    print(f"- Hit Task_A: {'YES' if hit_a else 'NO'}")
    print(f"- Hit Task_B: {'YES' if hit_b else 'NO'}")

    if hit_boot and hit_a and hit_b:
        print("SUCCESS: boot, Task_A và Task_B đều đã chạy trong khoảng virtual time kiểm tra.")
        return 0

    print("FAILED: Missing expected runtime markers.")
    print(f"Renode log: {RENODE_LOG}")
    return 1


if __name__ == "__main__":
    sys.exit(run_test())
