/*
 * ============================================================
 *  App_Task.c
 *  - Chứa toàn bộ task mẫu của ứng dụng.
 *  - Mục tiêu của file này không phải làm app phức tạp, mà để minh họa:
 *      + task init phần cứng
 *      + task định kỳ điều khiển LED
 *      + task định kỳ gửi UART
 *      + idle task ngủ chờ ngắt
 *
 *  Các task ở đây đều theo mô hình run-to-completion:
 *  - chạy xong một đơn vị công việc
 *  - gọi TerminateTask()
 *  - lần kích hoạt tiếp theo sẽ chạy lại từ đầu entry function
 * ============================================================
 */

#include "os_kernel.h"
#include "stm32f10x.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_usart.h"
#include <stdio.h>

/* =========================================================
 * BSP: LED PC13 (BluePill – thường active-low)
 *  - Dùng SPL thay vì truy cập thanh ghi trực tiếp
 *  - PC13: Output Push-Pull, 2 MHz
 * ========================================================= */
static void gpio_init_led(void)
{
    /* Phải bật clock port C trước thì thanh ghi GPIOC mới truy cập hợp lệ. */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

    /*
     * Cấu hình chân PC13 làm output push-pull.
     * Tốc độ 2 MHz là đủ cho LED, không cần tốc độ cao hơn.
     */
    GPIO_InitTypeDef io;
    io.GPIO_Pin = GPIO_Pin_13;
    io.GPIO_Speed = GPIO_Speed_2MHz;
    io.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOC, &io);

    /* Nhiều board BluePill LED nối về VCC qua điện trở → active-low.
       Đặt mức '1' để tắt LED mặc định. */
    GPIO_SetBits(GPIOC, GPIO_Pin_13);
}

/* Toggle LED dùng SPL:
 *  - Đọc mức hiện tại ODR bit 13 → đảo → ghi lại.
 *  - Không dùng trực tiếp ODR ^=, để tuân SPL. */
static inline void led_toggle(void)
{
    /*
     * Đọc mức hiện tại rồi ghi mức đảo lại.
     * Cách này giữ code rõ nghĩa hơn việc XOR trực tiếp thanh ghi ODR.
     */
    BitAction next = (BitAction)!GPIO_ReadOutputDataBit(GPIOC, GPIO_Pin_13);
    GPIO_WriteBit(GPIOC, GPIO_Pin_13, next);
}

/* =========================================================
 * BSP: UART1 TX (PA9) – 115200-8-N-1, TX polling
 *  - Dùng SPL hoàn toàn
 *  - Chỉ bật chân TX (PA9) ở chế độ AF Push-Pull
 * ========================================================= */
static void uart1_init_115200(void)
{
    /* GPIOA dùng cho PA9, USART1 cũng nằm trên bus APB2. */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_USART1, ENABLE);

    /* PA9 = USART1_TX (Alternate Function Push-Pull, 50MHz) */
    GPIO_InitTypeDef io;
    io.GPIO_Pin = GPIO_Pin_9;
    io.GPIO_Speed = GPIO_Speed_50MHz;
    io.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &io);

    /* (Tùy chọn) PA10 = USART1_RX nếu sau này cần:
       io.GPIO_Pin  = GPIO_Pin_10;
       io.GPIO_Mode = GPIO_Mode_IN_FLOATING;
       GPIO_Init(GPIOA, &io);
     */

    /*
     * Chỉ bật TX vì demo hiện tại chỉ cần in chuỗi ra host / analyzer.
     * Nếu sau này cần nhận dữ liệu, có thể mở rộng thêm PA10 + USART_Mode_Rx.
     */
    USART_InitTypeDef us;
    USART_StructInit(&us); /* set default trước */
    us.USART_BaudRate = 115200;
    us.USART_WordLength = USART_WordLength_8b;
    us.USART_StopBits = USART_StopBits_1;
    us.USART_Parity = USART_Parity_No;
    us.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    us.USART_Mode = USART_Mode_Tx; /* chỉ TX */
    USART_Init(USART1, &us);

    USART_Cmd(USART1, ENABLE);
}

static void uart1_send_char(char c)
{
    /*
     * Polling TX:
     * - đơn giản để minh họa
     * - không cần ISR/DMA
     * - phù hợp vì lượng dữ liệu debug rất ít
     */
    while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET)
    { /* wait */
    }
    USART_SendData(USART1, (uint16_t)c);
}

static void uart1_send_string(const char *s)
{
    /* Gửi tuần tự từng ký tự cho đến khi gặp ký tự kết thúc chuỗi. */
    while (*s)
    {
        uart1_send_char(*s++);
    }
}

/* =========================================================
 * Busy delay đơn giản (demo)
 *  - Thực tế OS nên có Alarm/Delay, ở đây giữ nguyên kiểu “ngủ nghèo”
 * ========================================================= */
static __attribute__((unused)) void busy_delay(volatile uint32_t loop)
{
    /*
     * Hàm này giữ lại chủ yếu cho mục đích demo/thí nghiệm.
     * Ở thiết kế OS thực tế, delay bận kiểu này nên tránh vì chiếm CPU vô ích.
     */
    while (loop--)
    {
        __asm volatile("nop");
    }
}

/* =========================================================
 * =====                TASKS (dùng OS)                =====
 * ========================================================= */

/* Task rỗi – vào WFI để tiết kiệm năng lượng khi không có READY */
void Task_Idle(void *arg)
{
    (void)arg;

    /*
     * Idle task là "task nền" của hệ thống.
     * Nó chỉ chạy khi không còn task ứng dụng nào READY/RUNNING.
     *
     * WFI giúp:
     * - tiết kiệm năng lượng
     * - nhường CPU cho ngắt kế tiếp đánh thức hệ thống
     */
    for (;;)
    {
#if OS_IDLE_USE_WFI
        __WFI();
#else
        __NOP();
#endif
    }
}

/* Task_A: Blink LED PC13
 * - Mỗi ~100ms toggle 1 lần (điều chỉnh loop theo SystemCoreClock)
 * - Dùng SPL cho GPIO (đã bọc trong led_toggle())
 */
void Task_A(void *arg)
{
    (void)arg;

    /*
     * Task_A được alarm kích định kỳ.
     * Mỗi lần chạy:
     * - in log để xác nhận scheduler đã vào đúng task
     * - đảo trạng thái LED
     * - kết thúc activation hiện tại
     */
    printf("Đã vào Task_A\r\n");

    uart1_send_string("[LED] Task_A\r\n");
    led_toggle();
    TerminateTask();

    for (;;)
    {
        /* code */
    }
}

/* Task_B: Gửi UART định kỳ
 * - Khung 115200-8-N-1
 * - Dùng polling TX cho đơn giản
 */
void Task_B(void *arg)
{
    (void)arg;

    /*
     * Task_B minh họa một workload khác với Task_A:
     * thay vì điều khiển GPIO, nó phát dữ liệu qua UART.
     * Điều này giúp dễ quan sát thứ tự chạy task qua analyzer/log.
     */
    printf("Đã vào Task_B\r\n");

    uart1_send_string("[UART] Hello from Task_B\r\n");

    TerminateTask();
}

/* Task_Init: khởi tạo peripheral (LED + UART), sau đó kết thúc
 * - Phần tạo ready-list/ActivateTask thường do OS hoặc main() đảm nhiệm.
 * - Ở đây chỉ thực hiện đúng vai trò “init phần cứng”.
 */
void Task_Init(void *arg)
{
    (void)arg;

    /*
     * Task_Init có priority cao nhất và chỉ chạy đầu tiên một lần.
     * Sau khi hoàn thành bootstrap phần cứng, task này tự kết thúc để
     * scheduler chuyển sang các task định kỳ khác.
     */
    printf("Đã vào Task_Init\r\n");

    /* 1) LED PC13 */
    gpio_init_led();

    /* 2) UART1 TX 115200 */
    uart1_init_115200();
    uart1_send_string("[BOOT] Peripherals initialized.\r\n");

    /* 3) Kết thúc activation khởi tạo. */
    TerminateTask();
}
