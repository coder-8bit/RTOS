Tools/SPL/src/stm32f10x_usart.o: SPL/src/stm32f10x_usart.c \
 SPL/inc/stm32f10x_usart.h SPL/inc/stm32f10x.h CMSIS/core_cm3.h \
 CMSIS/cmsis_version.h CMSIS/cmsis_compiler.h CMSIS/cmsis_gcc.h \
 SPL/inc/system_stm32f10x.h SPL/inc/stm32f10x_conf.h \
 SPL/inc/stm32f10x_rcc.h
SPL/inc/stm32f10x_usart.h:
SPL/inc/stm32f10x.h:
CMSIS/core_cm3.h:
CMSIS/cmsis_version.h:
CMSIS/cmsis_compiler.h:
CMSIS/cmsis_gcc.h:
SPL/inc/system_stm32f10x.h:
SPL/inc/stm32f10x_conf.h:
SPL/inc/stm32f10x_rcc.h:
