/*
 * =====================================================================
 *  Mini-OS Kernel Layer – phiên bản tối giản, chạy ổn định
 *  - READY queue: ring buffer có FULL/EMPTY
 *  - Alarm: SetRelAlarm(aid, delay_ms, cycle_ms, target_tid) (4 tham số)
 *           Lưu runtime theo tick (ms → tick qua OS_TICK_HZ)
 *  - schedule(): chọn next; nếu rỗng → IDLE
 *  - Bootstrap: tạo INIT/A/B/IDLE và launch qua SVC
 *  - Chính sách: run-to-completion (chỉ preempt khi đang ở IDLE)
 * =====================================================================
 */

#include "os_kernel.h"
#include "os_port.h" /* os_port_init(), os_task_stack_init(), os_trigger_pendsv(), OS_TICK_HZ */
#include "stm32f10x.h"
#include "cmsis_gcc.h"

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>

#include <stdio.h>

/* ==== Kiểm tra tối thiểu ==== */
#if (OS_MAX_TASKS < 2)
#error "OS_MAX_TASKS must be >= 2"
#endif

#if __STDC_VERSION__ >= 201112L
_Static_assert(OS_MAX_TASKS >= 2, "OS_MAX_TASKS must be >= 2");
_Static_assert(OS_MAX_TASKS <= 255, "OS_MAX_TASKS must be <= 255");
#endif

/* =========================================================
 *  Biến toàn cục Scheduler (ASM handler sẽ dùng 2 biến này)
 * ========================================================= */
volatile TCB_t *g_current = NULL;
volatile TCB_t *g_next = NULL;

/* =========================================================
 *  Vùng TCB & Stack (ứng dụng mẫu 4 task: INIT/A/B/IDLE)
 * ========================================================= */
static TCB_t tcb[OS_MAX_TASKS];

/* Kích thước stack (word = 4 byte) – điều chỉnh theo nhu cầu */
#define STACK_WORDS_INIT 128u
#define STACK_WORDS_A 96u
#define STACK_WORDS_B 96u
#define STACK_WORDS_IDLE 64u

static uint32_t stack_init[STACK_WORDS_INIT];
static uint32_t stack_a[STACK_WORDS_A];
static uint32_t stack_b[STACK_WORDS_B];
static uint32_t stack_idle[STACK_WORDS_IDLE];

/* =========================================================
 *  READY Queue (ring buffer) – chừa 1 ô để phân biệt FULL/EMPTY
 * ========================================================= */
static uint8_t ready_q[OS_MAX_TASKS];
static uint8_t rq_head = 0u; /* vị trí pop */
static uint8_t rq_tail = 0u; /* vị trí push */


typedef void (*TaskEntry)(void *);

static TaskEntry g_task_entry[OS_MAX_TASKS];
static void     *g_task_arg  [OS_MAX_TASKS];
static uint32_t *g_stack_top [OS_MAX_TASKS];


static inline void rq_reset(void)
{
    rq_head = 0u;
    rq_tail = 0u;
}

static inline bool rq_empty(void)
{
    return (rq_head == rq_tail);
}


static inline bool rq_full(void)
{
    /* chừa 1 ô: FULL khi (tail + 1) % N == head */
    return (uint8_t)((rq_tail + 1u) % OS_MAX_TASKS) == rq_head;
}

static inline bool rq_push(uint8_t tid)
{
    if (rq_full())
        return false;
    ready_q[rq_tail] = tid;
    rq_tail = (uint8_t)((rq_tail + 1u) % OS_MAX_TASKS);
    return true;
}



static inline bool rq_pop_raw(uint8_t *out_tid)
{
    if (rq_empty())
        return false;
    *out_tid = ready_q[rq_head];
    rq_head = (uint8_t)((rq_head + 1u) % OS_MAX_TASKS);
    return true;
}

/* =========================================================
 *  Alarm runtime & Tick Counter
 *  (OsAlarm_t do bạn khai báo trong os_kernel.h:
 *   active, target_task, remain_ms, cycle_ms)
 *  LƯU Ý: remain_ms/cycle_ms SẼ LƯU THEO TICK (đã quy đổi)
 * ========================================================= */
static OsAlarm_t alarm_tbl[OS_MAX_ALARMS];
static volatile uint32_t s_tick = 0;

/* Quy đổi ms → tick (làm tròn lên, tối thiểu 1 tick nếu ms>0) */
static inline uint32_t ms_to_ticks(uint32_t ms)
{
    if (ms == 0u)
        return 0u;
    uint64_t t = ((uint64_t)ms * (uint64_t)OS_TICK_HZ + 999ull) / 1000ull;
    if (t == 0ull)
        t = 1ull;
    if (t > 0xFFFFFFFFull)
        t = 0xFFFFFFFFull;
    return (uint32_t)t;
}

/* =========================================================
 *  Khai báo thân Task do ứng dụng cung cấp
 * ========================================================= */
extern void Task_Init(void *arg);
extern void Task_A(void *arg);
extern void Task_B(void *arg);
extern void Task_Idle(void *arg);

/* =========================================================
 * schedule()
 * ---------------------------------------------------------
 * Mục tiêu:
 *   - Chọn "next" (TCB kế tiếp) để chạy.
 *   - Nếu READY queue rỗng → chọn IDLE.
 *   - Đặt yêu cầu đổi ngữ cảnh bằng PendSV (trì hoãn tới cuối ISR).
 *
 * Bối cảnh gọi:
 *   - Có thể được gọi trong ISR (ví dụ từ os_on_tick) hoặc từ Thread
 *     (ví dụ TerminateTask). Nếu gọi từ Thread, caller nên bọc vùng
 *     tới hạn (tắt IRQ ngắn hạn) trước/sau khi gọi để tránh race
 *     với ISR cũng đang thao tác READY queue.
 *
 * Quy ước:
 *   - g_next: con trỏ TCB của task sẽ được chuyển tới (vé chuyển cảnh).
 *     + Nếu g_next != NULL: đã có chuyển ngữ cảnh pending → không
 *       chọn thêm (tránh ghi đè vé cũ).
 *   - rq_pop_raw(): pop 1 task ID từ READY queue (không tự bọc IRQ).
 *   - TASK_IDLE: task rỗi, KHÔNG enqueue; chỉ được chọn khi queue rỗng.
 *   - os_trigger_pendsv(): đặt bit PENDSVSET để yêu cầu PendSV chạy.
 *
 * Yêu cầu với PendSV_Handler:
 *   - Sau khi chuyển xong: g_current = g_next; g_next = NULL;
 *     (xóa vé) để lần sau schedule() có thể đặt vé mới.
 *
 * Trả về:
 *   - true luôn (vì nếu không có READY thì vẫn chọn IDLE).
 * ========================================================= */
static bool schedule(void)
{
    if (g_next != NULL) return true;

    uint8_t tid = 0u;
    TCB_t *next = NULL;
    bool ok = rq_pop_raw(&tid);
    if (!ok) {
        // Không có READY → đừng pendsv; để task hiện tại tiếp tục chạy
        next = &tcb[TASK_IDLE];
        
    }else {
        next = &tcb[tid];
        if (next->state != OS_READY) {
            // Lỗi logic: task không ở trạng thái READY
            next = &tcb[TASK_IDLE];
        } else {
            next->state = OS_RUNNING;
        }
    }
    g_next = next;
    __DSB(); __ISB();
    os_trigger_pendsv();
    return true;
}

/* =========================================================
 *  ActivateTask(): DORMANT → READY (không kích chồng)
 * ========================================================= */
void ActivateTask(uint8_t tid)
{
    if (tid >= OS_MAX_TASKS || tid == TASK_IDLE) return;

    __disable_irq();
    TCB_t *t = &tcb[tid];
    if (t->state == OS_DORMANT) {
        /* *** Quan trọng: dựng lại PSP để task chạy lại từ đầu entry *** */
        t->sp    = os_task_stack_init(g_task_entry[tid], g_task_arg[tid], g_stack_top[tid]);
        t->state = OS_READY;
        (void)rq_push(tid);

        /* Fast-path: nếu đang Idle và chưa pending thì chuyển ngay (tuỳ bạn) */
        if ((g_current == &tcb[TASK_IDLE]) && (g_next == NULL)) {
            __DSB(); __ISB();
            os_trigger_pendsv();
        }
    }
    __enable_irq();
}

/* =========================================================
 *  TerminateTask(): Task tự kết thúc → DORMANT và chuyển lịch
 * ========================================================= */
void TerminateTask(void)
{
    __disable_irq();

    TCB_t *cur = (TCB_t *)g_current;
    if (cur)
    {
        cur->state = OS_DORMANT;
    }

    (void)schedule(); /* chọn READY khác; nếu rỗng → IDLE */

    __enable_irq();

    /* Không quay lại thân task nữa */
    for (;;)
    {
        __NOP();
    }
}

/* =========================================================
 *  SetRelAlarm(aid, delay_ms, cycle_ms, target_tid) – 4 tham số
 *   - Lưu runtime theo tick (ms → tick)
 *   - Nếu đang active: ghi đè cấu hình mới
 * ========================================================= */
void SetRelAlarm(uint8_t aid, uint32_t delay_ms, uint32_t cycle_ms, uint8_t target_tid)
{
    if (aid >= OS_MAX_ALARMS)
        return;
    if (target_tid >= OS_MAX_TASKS)
        return;

    uint32_t inc_ticks = ms_to_ticks(delay_ms == 0u ? 1u : delay_ms);
    uint32_t cyc_ticks = ms_to_ticks(cycle_ms);
    if ((cyc_ticks > 0u) && (cyc_ticks < 1u))
    {
        cyc_ticks = 1u; /* ép tối thiểu 1 tick nếu có chu kỳ */
    }

    __disable_irq();

    OsAlarm_t *a = &alarm_tbl[aid];
    a->active = 1u;
    a->target_task = target_tid;
    a->remain_ms = inc_ticks; /* LƯU THEO TICK */
    a->cycle_ms = cyc_ticks;  /* LƯU THEO TICK */

    __enable_irq();
}

/* =========================================================
 *  os_on_tick(): gọi mỗi nhịp SysTick (ISR context)
 *   - Tăng tick, quét Alarm → ActivateTask() khi đến hạn
 *   - Run-to-completion: chỉ schedule ngay khi current là IDLE
 * ========================================================= */
void os_on_tick(void)
{
    s_tick++;

    /* Quét mọi alarm (ISR: atomic với thread) */
    for (uint8_t i = 0u; i < OS_MAX_ALARMS; ++i)
    {
        OsAlarm_t *a = &alarm_tbl[i];
        if (!a->active)
            continue;

        if (a->remain_ms > 0u)
        {
            a->remain_ms--;
        }

        if (a->remain_ms == 0u)
        {
         /* Kích hoạt task đích */
            ActivateTask(a->target_task);

            /* Lặp hay one-shot */
            if (a->cycle_ms > 0u) {
                a->remain_ms = a->cycle_ms; /* nạp lại chu kỳ */
            } else {
                a->active = 0u; /* one-shot → tắt */
            }   
        }
    }

    /* Giảm latency: nếu chưa có pending switch và đang ở IDLE → chọn ngay */
    if ((g_next == NULL) && (g_current == &tcb[TASK_IDLE])) {
        (void)schedule();
    }
}

/* Alias nếu nơi khác gọi tên này */
void os_tick_handler(void)
{
    os_on_tick();
}

/* =========================================================
 *  OS_Init(): khởi tạo OS + tạo 4 task mẫu: INIT / A / B / IDLE
 *   - Dựng stack cho từng task (os_task_stack_init trả về &R4)
 *   - READY queue: chỉ đẩy INIT (IDLE KHÔNG enqueue)
 *   - g_current = INIT để SVC launch Task_Init
 *   - Đặt alarm mẫu: AID 0 cho TASK_A, AID 1 cho TASK_B
 * ========================================================= */
void OS_Init(void)
{
    __disable_irq();
    os_port_init();

    /* Lưu entry/arg/stack top để tái dựng khi Activate */
    g_task_entry[TASK_INIT] = Task_Init;  g_task_arg[TASK_INIT] = 0; g_stack_top[TASK_INIT] = &stack_init[STACK_WORDS_INIT];
    g_task_entry[TASK_A]    = Task_A;     g_task_arg[TASK_A]    = 0; g_stack_top[TASK_A]    = &stack_a[STACK_WORDS_A];
    g_task_entry[TASK_B]    = Task_B;     g_task_arg[TASK_B]    = 0; g_stack_top[TASK_B]    = &stack_b[STACK_WORDS_B];
    g_task_entry[TASK_IDLE] = Task_Idle;  g_task_arg[TASK_IDLE] = 0; g_stack_top[TASK_IDLE] = &stack_idle[STACK_WORDS_IDLE];

    /* Dựng stack lần đầu */
    tcb[TASK_INIT].sp    = os_task_stack_init(g_task_entry[TASK_INIT], g_task_arg[TASK_INIT], g_stack_top[TASK_INIT]);
    tcb[TASK_INIT].id    = TASK_INIT;
    tcb[TASK_INIT].state = OS_READY;

    tcb[TASK_A].sp       = os_task_stack_init(g_task_entry[TASK_A],    g_task_arg[TASK_A],    g_stack_top[TASK_A]);
    tcb[TASK_A].id       = TASK_A;
    tcb[TASK_A].state    = OS_DORMANT;

    tcb[TASK_B].sp       = os_task_stack_init(g_task_entry[TASK_B],    g_task_arg[TASK_B],    g_stack_top[TASK_B]);
    tcb[TASK_B].id       = TASK_B;
    tcb[TASK_B].state    = OS_DORMANT;

    tcb[TASK_IDLE].sp    = os_task_stack_init(g_task_entry[TASK_IDLE], g_task_arg[TASK_IDLE], g_stack_top[TASK_IDLE]);
    tcb[TASK_IDLE].id    = TASK_IDLE;
    tcb[TASK_IDLE].state = OS_READY;   /* không enqueue IDLE */

    rq_head = rq_tail = 0;
    (void)rq_push(TASK_INIT);
    g_current = &tcb[TASK_INIT];

    /* ví dụ alarm */
    SetRelAlarm(0u, 500u, 1000u, TASK_A);
    SetRelAlarm(1u, 600u,  300u, TASK_B);

    __enable_irq();
}
/* =========================================================
 *  OS_Start(): gọi SVC để “launch” task đầu tiên
 *   - SVC_Handler (ASM) sẽ:
 *      + lấy g_current->sp → pop SW-frame (R4..R11)
 *      + set PSP = &R0
 *      + EXC_RETURN về Thread mode/PSP → chạy Task_Init()
 * ========================================================= */
void OS_Start(void)
{
    __ASM volatile("svc 0");
}
