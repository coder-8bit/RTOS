#pragma once
#include <stdint.h>

typedef enum { OS_DORMANT=0, OS_READY=1, OS_RUNNING=2 } OsTaskState_e;

typedef struct {
    uint8_t   active;
    uint32_t  remain_ms;
    uint32_t  cycle_ms;
    uint8_t   target_task; /* TaskId_e */
} OsAlarm_t;
